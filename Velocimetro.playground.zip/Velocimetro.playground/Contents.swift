//: Playground - Velocimetro
//: Autor : Stalyn Chiquito

import UIKit

enum Velocidades: Int {
    
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init(velocidadInicial: Velocidades){
        self = velocidadInicial
    }
}


class Auto{
    var velocidad :  Velocidades
    
    init(velocidadInicial: Velocidades){
        self.velocidad = velocidadInicial
    }
    
    
    func cambioDeVelocidad() -> ( actual : Int, velocidadEnCadena: String){
        
        var actual: Int
        var velocidadEnCadena: String = ""
        
        actual = velocidad.rawValue
        
        switch velocidad {
        case Velocidades.Apagado:
            velocidadEnCadena = "Apagado"
            velocidad = Velocidades.VelocidadBaja
        case Velocidades.VelocidadBaja:
            velocidadEnCadena = "Velocidad Baja"
            velocidad = Velocidades.VelocidadMedia
        case Velocidades.VelocidadMedia:
            velocidadEnCadena = "Velocidad Media"
            velocidad = Velocidades.VelocidadAlta
        case Velocidades.VelocidadAlta:
            velocidadEnCadena = "Velocidad Alta"
            velocidad = Velocidades.VelocidadMedia
        
        default:
            velocidadEnCadena = "Apagado"
            velocidad = Velocidades.Apagado
            
        }
        
        return (actual,velocidadEnCadena)
        
    }
    
}

var auto = Auto(velocidadInicial: Velocidades.Apagado)
var CambioVelocidad = (actual:0, velocidadEnCadena:"")

for i in 1...20{
    CambioVelocidad = auto.cambioDeVelocidad()
    print (" \(CambioVelocidad.actual), \(CambioVelocidad.velocidadEnCadena)")
}
    





